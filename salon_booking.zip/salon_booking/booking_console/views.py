from datetime import date, datetime, timedelta
from django.shortcuts import render
from booking_console.models import Salon, Chair, Service, Booking
from booking_console.constants import DEFAULT_START_TIME, DEFAULT_END_TIME, DEFAULT_CUSTOMER, DEFAULT_SLOT_DURATION,\
DUMMY_SALON_DATA, DUMMY_CHAIR_DATA, DUMMY_SERVICE_DATA
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.
def get_available_slots(request):
    errors = []
    messages = []
    if request.method == "GET":
        return render(request=request, template_name="index.html",
            context={"slots": [],
            "errors": errors,
            "messages": messages,
            "salon_list": Salon.objects.all(),
            "service_list": Service.objects.all()})
    else:
        if "book_id" in request.POST and request.POST["book_id"]:
            booking = Booking.objects.get(id=int(request.POST["book_id"]))
            book_corresponding_slot(booking)
            messages.append("Successfully Booked the Slot.")
            salon = booking.salon
            service = booking.service
            request_date = booking.start_time.date()
        else:
            try:
                salon_id = request.POST["salon_id"]
                salon = Salon.objects.get(id=salon_id)
            except:
                errors.append("Salon Details are not correct")
                salon = None
            try:
                service_id = request.POST["service_id"]
                service = Service.objects.get(id=service_id)
            except:
                errors.append("Service Details are not correct")
                service = None
            try:
                request_date = datetime.strptime(request.POST["date"], '%Y-%m-%d').date()
            except:
                errors.append("Request date is wrong")
                request_date = None
        if salon and service and request_date:
            if not Booking.objects.filter(start_time__date=request_date).exists():
                generate_slots_for_the_date(salon, service, request_date)
            slots = get_slots_for_the_date(salon, service, request_date)
            return render(request=request, template_name="index.html",
            context={"slots": slots,
            "errors": errors,
            "messages": messages,
            "salon_list": Salon.objects.all(),
            "service_list": Service.objects.all()})
        else:
            return render(request=request, template_name="index.html",
            context={"slots": [],
            "errors": errors,
            "messages": messages,
            "salon_list": Salon.objects.all(),
            "service_list": Service.objects.all()})

def generate_slots_for_the_date(salon, service, request_date):
    start_time = datetime.strptime(DEFAULT_START_TIME, "%H:%M").time()
    end_time = datetime.strptime(DEFAULT_END_TIME, "%H:%M").time()
    for chair in Chair.objects.filter(salon=salon):
        for service in Service.objects.all():
            start_date_time = datetime.combine(request_date, start_time)
            end_date_time = datetime.combine(request_date, end_time)
            while start_date_time < end_date_time and (start_date_time + timedelta(minutes=service.duration)) < end_date_time:
                Booking.objects.create(
                    salon=salon,
                    chair=chair,
                    service=service,
                    start_time=start_date_time
                )
                start_date_time = start_date_time + timedelta(minutes=DEFAULT_SLOT_DURATION)

def get_slots_for_the_date(salon, service, request_date):
    return Booking.objects.filter(salon=salon,service=service,customer=None,start_time__date=request_date)

#book a slot,
#operations
# 1. add customer details to existing slots.
# 2. delete overlapping slots
def book_corresponding_slot(booking):
    booking.customer = DEFAULT_CUSTOMER
    overlap_before_time = (booking.start_time - timedelta(minutes=booking.service.duration))
    overlap_after_time = (booking.start_time + timedelta(minutes=booking.service.duration))
    Booking.objects.exclude(id=booking.id).filter(start_time__gt=overlap_before_time,start_time__lt=booking.start_time).delete()
    Booking.objects.exclude(id=booking.id).filter(start_time__lt=overlap_after_time,start_time__gt=booking.start_time).delete()
    booking.save()
    return True

def generate_dummy_data(request):
    if request.method == "GET":
        Salon.objects.all().delete()
        for salon in DUMMY_SALON_DATA:
            salon = Salon.objects.create(**salon)
        Service.objects.all().delete()
        for service in DUMMY_SERVICE_DATA:
            Service.objects.create(**service)
        Chair.objects.all().delete()
        for chair in DUMMY_CHAIR_DATA:
            Chair.objects.create(
                number=chair["number"],
                salon=salon
            )
        return HttpResponseRedirect(reverse('get_available_slots'))