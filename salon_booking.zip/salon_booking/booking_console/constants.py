DEFAULT_SLOT_DURATION = 30 #duration for a particular slot -> 30 minutes
DEFAULT_SERVICE_DURATION = 30 # default service duration used in models.py
DEFAULT_START_TIME = "09:00"
DEFAULT_END_TIME = "17:00"
DEFAULT_CUSTOMER = "Default User"

# dummy data values
DUMMY_SALON_DATA = [{"name": "Salon 1"}]
DUMMY_SERVICE_DATA = [{"name": "Hair Cut", "cost": 120, "duration": 45},
{"name": "Hair Dye", "cost": 200, "duration": 110}]
DUMMY_CHAIR_DATA = [{"number": 1}]