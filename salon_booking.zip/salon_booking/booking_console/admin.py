from django.contrib import admin
from booking_console import models

# Register your models here.


admin.site.register(models.Service)
admin.site.register(models.Chair)
admin.site.register(models.Salon)