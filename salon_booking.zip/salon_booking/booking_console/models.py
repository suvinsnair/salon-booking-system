from django.db import models
from booking_console.constants import DEFAULT_SERVICE_DURATION

# Create your models here.
class Salon(models.Model):
    name = models.CharField(max_length=20)

class Service(models.Model):
    name = models.CharField(max_length=20)
    cost = models.IntegerField(default=0)
    duration = models.IntegerField(default=DEFAULT_SERVICE_DURATION)

class Chair(models.Model):
    number = models.IntegerField(default=1)
    salon = models.ForeignKey(Salon, on_delete=models.CASCADE)

class Booking(models.Model):
    salon = models.ForeignKey(Salon, on_delete=models.CASCADE)
    chair = models.ForeignKey(Chair, on_delete=models.CASCADE)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    start_time = models.DateTimeField()
    customer = models.CharField(max_length=15, null=True, default=None)